package ch.epfl.javelo;

import ch.epfl.javelo.projection.SwissBounds;

public class Test {
    public static void main(String[] args) {
        A.aVoid();
    }
}

class A {
    public static void aVoid() {
        System.out.println("f");
    }
}
